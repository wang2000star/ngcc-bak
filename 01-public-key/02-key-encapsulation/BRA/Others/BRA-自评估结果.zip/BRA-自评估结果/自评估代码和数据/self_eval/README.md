# x86 Self-Evaluation

This directory contains reproducible x86 self-evaluation evidence for the NGCC
KEM implementations in this repository.

Run the complete build first:

```bash
python -B rbc-lib.py config.yml
```

Then run the x86 self-evaluation:

```bash
python -B script/self_eval/run_x86_self_eval.py --config config.yml --out self_eval/results/current --samples 50 --reference-inner-runs 10 --optimized-inner-runs 100 --warmup-runs 5 --cpu 0
```

The default run also compiles and times the baseline FrodoKEM and HQC
implementations under `baseline/` for performance comparison. Use
`--skip-baseline` only when debugging the NGCC submission implementations alone.

The generated evidence is written to `self_eval/results/current/`:

- `environment.json`: hardware/software environment and test parameters.
- `kat.csv`: KAT comparison results for reference and optimized implementations.
- `performance.csv`: keygen, encaps and decaps timing results for NGCC
  candidates and baseline algorithms. The default command expands the
  algorithm-text benchmark scale to 50 independent samples while keeping 10
  inner runs per reference sample, 100 inner runs per optimized sample, and 5
  warm-up samples.
- `raw_cycles.csv`: one row per measured sample with inner-loop mean, median,
  standard deviation, and intra-sample CV; warm-up samples are excluded.
- `resources.csv`: static size and peak RSS results.
- `sizes.csv`: public key, secret key, ciphertext and shared secret sizes.
- `commands.log`: exact commands and raw command output.

The official English LaTeX/PDF reports are generated per candidate algorithm:

- `self_eval/report_x86_bra.tex` and `self_eval/report_x86_bra.pdf`
- `self_eval/report_x86_brqc.tex` and `self_eval/report_x86_brqc.pdf`
- `self_eval/report_x86_cmultiurag.tex` and `self_eval/report_x86_cmultiurag.pdf`

The legacy Markdown report, when present, is an auxiliary readable copy only.
