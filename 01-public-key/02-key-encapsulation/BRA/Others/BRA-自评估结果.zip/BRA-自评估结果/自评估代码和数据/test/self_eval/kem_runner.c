#define _POSIX_C_SOURCE 200809L

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef SELF_EVAL_HEADER
#include SELF_EVAL_HEADER
#endif

#ifndef SELF_EVAL_ALGORITHM
#error "SELF_EVAL_ALGORITHM must be defined"
#endif
#ifndef SELF_EVAL_INSTANCE
#error "SELF_EVAL_INSTANCE must be defined"
#endif
#ifndef SELF_EVAL_VERSION
#error "SELF_EVAL_VERSION must be defined"
#endif
#ifndef SELF_EVAL_KEYGEN
#error "SELF_EVAL_KEYGEN must be defined"
#endif
#ifndef SELF_EVAL_ENCAPS
#error "SELF_EVAL_ENCAPS must be defined"
#endif
#ifndef SELF_EVAL_DECAPS
#error "SELF_EVAL_DECAPS must be defined"
#endif
#ifndef SELF_EVAL_PUBLIC_KEY_BYTES
#error "SELF_EVAL_PUBLIC_KEY_BYTES must be defined"
#endif
#ifndef SELF_EVAL_SECRET_KEY_BYTES
#error "SELF_EVAL_SECRET_KEY_BYTES must be defined"
#endif
#ifndef SELF_EVAL_CIPHERTEXT_BYTES
#error "SELF_EVAL_CIPHERTEXT_BYTES must be defined"
#endif
#ifndef SELF_EVAL_SHARED_SECRET_BYTES
#error "SELF_EVAL_SHARED_SECRET_BYTES must be defined"
#endif

#ifdef SELF_EVAL_USE_RANDOMBYTES_INIT
void randombytes_init(unsigned char *entropy_input, unsigned char *personalization_string,
                      int security_strength);
#endif

#ifdef SELF_EVAL_USE_HQC_PRNG_INIT
void prng_init(uint8_t *entropy_input, uint8_t *personalization_string, uint32_t enlen,
               uint32_t perlen);
#endif

typedef struct {
  unsigned long long mean;
  unsigned long long median;
  unsigned long long stddev;
} stats_t;

static inline uint64_t cpucycles_start(void) {
  unsigned hi, lo;
  __asm__ __volatile__(
      "CPUID\n\t"
      "RDTSC\n\t"
      "mov %%edx, %0\n\t"
      "mov %%eax, %1\n\t"
      : "=r"(hi), "=r"(lo)
      :
      : "%rax", "%rbx", "%rcx", "%rdx");
  return ((uint64_t)lo) ^ (((uint64_t)hi) << 32);
}

static inline uint64_t cpucycles_stop(void) {
  unsigned hi, lo;
  __asm__ __volatile__(
      "RDTSCP\n\t"
      "mov %%edx, %0\n\t"
      "mov %%eax, %1\n\t"
      "CPUID\n\t"
      : "=r"(hi), "=r"(lo)
      :
      : "%rax", "%rbx", "%rcx", "%rdx");
  return ((uint64_t)lo) ^ (((uint64_t)hi) << 32);
}

static int cmp_u64(const void *a, const void *b) {
  const unsigned long long va = *(const unsigned long long *)a;
  const unsigned long long vb = *(const unsigned long long *)b;
  if(va < vb) return -1;
  if(va > vb) return 1;
  return 0;
}

static unsigned long long isqrt_u64(unsigned long long x) {
  if(x < 2) return x;
  unsigned long long r = x;
  unsigned long long prev;
  do {
    prev = r;
    r = (r + x / r) >> 1;
  } while(r < prev);
  return prev;
}

static void compute_stats(const unsigned long long *samples, size_t n, stats_t *out) {
  unsigned long long sum = 0;
  for(size_t i = 0; i < n; i++) sum += samples[i];
  out->mean = n ? sum / n : 0;

  unsigned long long sqsum = 0;
  for(size_t i = 0; i < n; i++) {
    const long long d = (long long)samples[i] - (long long)out->mean;
    sqsum += (unsigned long long)(d * d);
  }
  out->stddev = (n > 1) ? isqrt_u64(sqsum / (n - 1)) : 0;

  unsigned long long *sorted = calloc(n ? n : 1, sizeof(*sorted));
  if(sorted == NULL) {
    out->median = 0;
    return;
  }
  memcpy(sorted, samples, n * sizeof(*sorted));
  qsort(sorted, n, sizeof(*sorted), cmp_u64);
  out->median = (n == 0) ? 0 : ((n % 2 == 0) ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 : sorted[n / 2]);
  free(sorted);
}

static unsigned long long max_u64(const unsigned long long *samples, size_t n) {
  unsigned long long max = 0;
  for(size_t i = 0; i < n; i++) {
    if(samples[i] > max) max = samples[i];
  }
  return max;
}

static unsigned long long cv_basis_points(const stats_t *stats) {
  if(stats->mean == 0) return 0;
  return (stats->stddev * 10000ULL + stats->mean / 2ULL) / stats->mean;
}

static double now_seconds(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}

static int hex_value(char c) {
  if(c >= '0' && c <= '9') return c - '0';
  if(c >= 'a' && c <= 'f') return c - 'a' + 10;
  if(c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

static int parse_seed(const char *hex, unsigned char seed[48]) {
  if(hex == NULL) {
    for(size_t i = 0; i < 48; i++) seed[i] = (unsigned char)i;
    return 0;
  }
  if(strlen(hex) != 96) return -1;
  for(size_t i = 0; i < 48; i++) {
    const int high = hex_value(hex[2 * i]);
    const int low = hex_value(hex[2 * i + 1]);
    if(high < 0 || low < 0) return -1;
    seed[i] = (unsigned char)((high << 4) | low);
  }
  return 0;
}

static void print_result(const char *operation, int samples, int inner_runs, int failures,
                         const stats_t *stats, const stats_t *intra_cv_stats,
                         unsigned long long intra_cv_max, double wall_seconds) {
  const double ops = (double)samples * (double)inner_runs;
  const double ops_per_second = wall_seconds > 0.0 ? ops / wall_seconds : 0.0;
  printf("SELF_EVAL,%s,%s,%s,%s,%d,%d,%d,%llu,%llu,%llu,%llu.%02llu,%llu.%02llu,%llu.%02llu,%.9f,%.3f\n",
         SELF_EVAL_ALGORITHM,
         SELF_EVAL_INSTANCE,
         SELF_EVAL_VERSION,
         operation,
         samples,
         inner_runs,
         failures,
         stats->mean,
         stats->median,
         stats->stddev,
         intra_cv_stats->mean / 100,
         intra_cv_stats->mean % 100,
         intra_cv_stats->median / 100,
         intra_cv_stats->median % 100,
         intra_cv_max / 100,
         intra_cv_max % 100,
         wall_seconds,
         ops_per_second);
}

static void print_raw_sample(const char *operation, int sample_index, const stats_t *inner_stats,
                             unsigned long long intra_cv) {
  printf("SELF_EVAL_SAMPLE,%s,%s,%s,%s,%d,%llu,%llu,%llu,%llu.%02llu\n",
         SELF_EVAL_ALGORITHM,
         SELF_EVAL_INSTANCE,
         SELF_EVAL_VERSION,
         operation,
         sample_index,
         inner_stats->mean,
         inner_stats->median,
         inner_stats->stddev,
         intra_cv / 100,
         intra_cv % 100);
}

static int run_unmeasured_operation(const char *operation, int inner_runs,
                                    unsigned char *pk, unsigned char *sk, unsigned char *ct,
                                    unsigned char *ss1, unsigned char *ss2) {
  int failures = 0;

  if(strcmp(operation, "keygen") == 0) {
    for(int j = 0; j < inner_runs; j++) {
      if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
    }
  } else if(strcmp(operation, "encaps") == 0) {
    if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
    for(int j = 0; j < inner_runs; j++) {
      if(SELF_EVAL_ENCAPS(ct, ss1, pk) != 0) failures++;
    }
  } else if(strcmp(operation, "decaps") == 0) {
    if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
    if(SELF_EVAL_ENCAPS(ct, ss1, pk) != 0) failures++;
    for(int j = 0; j < inner_runs; j++) {
      if(SELF_EVAL_DECAPS(ss2, ct, sk) != 0) failures++;
      if(memcmp(ss1, ss2, SELF_EVAL_SHARED_SECRET_BYTES) != 0) failures++;
    }
  } else {
    failures++;
  }

  return failures;
}

static int run_operation(const char *operation, int samples, int inner_runs, int warmup_runs,
                         int raw_samples,
                         unsigned char *pk, unsigned char *sk, unsigned char *ct,
                         unsigned char *ss1, unsigned char *ss2) {
  unsigned long long *cycle_samples = calloc((size_t)samples, sizeof(*cycle_samples));
  unsigned long long *inner_cycles = calloc((size_t)inner_runs, sizeof(*inner_cycles));
  unsigned long long *intra_cv_samples = calloc((size_t)samples, sizeof(*intra_cv_samples));
  if(cycle_samples == NULL || inner_cycles == NULL || intra_cv_samples == NULL) {
    free(cycle_samples);
    free(inner_cycles);
    free(intra_cv_samples);
    return 2;
  }

  int failures = 0;
  double wall_seconds = 0.0;

  for(int i = 0; i < warmup_runs; i++) {
    failures += run_unmeasured_operation(operation, inner_runs, pk, sk, ct, ss1, ss2);
  }

  for(int i = 0; i < samples; i++) {
    uint64_t t1, t2;
    double w1, w2;

    if(strcmp(operation, "keygen") == 0) {
      w1 = now_seconds();
      for(int j = 0; j < inner_runs; j++) {
        t1 = cpucycles_start();
        if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
        t2 = cpucycles_stop();
        inner_cycles[j] = t2 - t1;
      }
      w2 = now_seconds();
    } else if(strcmp(operation, "encaps") == 0) {
      if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
      w1 = now_seconds();
      for(int j = 0; j < inner_runs; j++) {
        t1 = cpucycles_start();
        if(SELF_EVAL_ENCAPS(ct, ss1, pk) != 0) failures++;
        t2 = cpucycles_stop();
        inner_cycles[j] = t2 - t1;
      }
      w2 = now_seconds();
    } else if(strcmp(operation, "decaps") == 0) {
      if(SELF_EVAL_KEYGEN(pk, sk) != 0) failures++;
      if(SELF_EVAL_ENCAPS(ct, ss1, pk) != 0) failures++;
      if(SELF_EVAL_DECAPS(ss2, ct, sk) != 0) failures++;
      if(memcmp(ss1, ss2, SELF_EVAL_SHARED_SECRET_BYTES) != 0) failures++;
      w1 = now_seconds();
      for(int j = 0; j < inner_runs; j++) {
        t1 = cpucycles_start();
        if(SELF_EVAL_DECAPS(ss2, ct, sk) != 0) failures++;
        t2 = cpucycles_stop();
        inner_cycles[j] = t2 - t1;
      }
      w2 = now_seconds();
    } else {
      free(cycle_samples);
      free(inner_cycles);
      free(intra_cv_samples);
      return 3;
    }

    wall_seconds += w2 - w1;
    stats_t inner_stats;
    compute_stats(inner_cycles, (size_t)inner_runs, &inner_stats);
    const unsigned long long intra_cv = cv_basis_points(&inner_stats);
    cycle_samples[i] = inner_stats.mean;
    intra_cv_samples[i] = intra_cv;
    if(raw_samples) {
      print_raw_sample(operation, i + 1, &inner_stats, intra_cv);
    }
  }

  stats_t stats;
  stats_t intra_cv_stats;
  compute_stats(cycle_samples, (size_t)samples, &stats);
  compute_stats(intra_cv_samples, (size_t)samples, &intra_cv_stats);
  print_result(operation, samples, inner_runs, failures, &stats, &intra_cv_stats,
               max_u64(intra_cv_samples, (size_t)samples), wall_seconds);
  free(cycle_samples);
  free(inner_cycles);
  free(intra_cv_samples);
  return failures == 0 ? 0 : 1;
}

int main(int argc, char **argv) {
  int samples = 100;
  int inner_runs = 100;
  int warmup_runs = 0;
  int raw_samples = 0;
  const char *seed_hex = NULL;
  const char *operation = "all";

  for(int i = 1; i < argc; i++) {
    if(strcmp(argv[i], "--samples") == 0 && i + 1 < argc) {
      samples = atoi(argv[++i]);
    } else if(strcmp(argv[i], "--inner-runs") == 0 && i + 1 < argc) {
      inner_runs = atoi(argv[++i]);
    } else if(strcmp(argv[i], "--warmup-runs") == 0 && i + 1 < argc) {
      warmup_runs = atoi(argv[++i]);
    } else if(strcmp(argv[i], "--raw-samples") == 0) {
      raw_samples = 1;
    } else if(strcmp(argv[i], "--seed") == 0 && i + 1 < argc) {
      seed_hex = argv[++i];
    } else if(strcmp(argv[i], "--operation") == 0 && i + 1 < argc) {
      operation = argv[++i];
    } else {
      fprintf(stderr, "usage: %s [--samples N] [--inner-runs N] [--warmup-runs N] [--raw-samples] [--seed HEX48] [--operation keygen|encaps|decaps|all]\n", argv[0]);
      return 2;
    }
  }

  if(samples <= 0 || inner_runs <= 0) {
    fprintf(stderr, "samples and inner-runs must be positive\n");
    return 2;
  }
  if(warmup_runs < 0) {
    fprintf(stderr, "warmup-runs must be non-negative\n");
    return 2;
  }

  unsigned char seed[48];
  if(parse_seed(seed_hex, seed) != 0) {
    fprintf(stderr, "seed must be 96 hex characters\n");
    return 2;
  }

#ifdef SELF_EVAL_USE_RANDOMBYTES_INIT
  randombytes_init(seed, NULL, 256);
#endif
#ifdef SELF_EVAL_USE_HQC_PRNG_INIT
  prng_init(seed, NULL, 48, 0);
#endif

  unsigned char *pk = calloc(SELF_EVAL_PUBLIC_KEY_BYTES, 1);
  unsigned char *sk = calloc(SELF_EVAL_SECRET_KEY_BYTES, 1);
  unsigned char *ct = calloc(SELF_EVAL_CIPHERTEXT_BYTES, 1);
  unsigned char *ss1 = calloc(SELF_EVAL_SHARED_SECRET_BYTES, 1);
  unsigned char *ss2 = calloc(SELF_EVAL_SHARED_SECRET_BYTES, 1);

  if(pk == NULL || sk == NULL || ct == NULL || ss1 == NULL || ss2 == NULL) {
    fprintf(stderr, "allocation failure\n");
    free(pk);
    free(sk);
    free(ct);
    free(ss1);
    free(ss2);
    return 2;
  }

  int status = 0;
  if(strcmp(operation, "all") == 0 || strcmp(operation, "keygen") == 0) {
    status |= run_operation("keygen", samples, inner_runs, warmup_runs, raw_samples, pk, sk, ct, ss1, ss2);
  }
  if(strcmp(operation, "all") == 0 || strcmp(operation, "encaps") == 0) {
    status |= run_operation("encaps", samples, inner_runs, warmup_runs, raw_samples, pk, sk, ct, ss1, ss2);
  }
  if(strcmp(operation, "all") == 0 || strcmp(operation, "decaps") == 0) {
    status |= run_operation("decaps", samples, inner_runs, warmup_runs, raw_samples, pk, sk, ct, ss1, ss2);
  }
  if(strcmp(operation, "all") != 0 &&
     strcmp(operation, "keygen") != 0 &&
     strcmp(operation, "encaps") != 0 &&
     strcmp(operation, "decaps") != 0) {
    fprintf(stderr, "operation must be keygen, encaps, decaps, or all\n");
    status = 2;
  }

  free(pk);
  free(sk);
  free(ct);
  free(ss1);
  free(ss2);
  return status;
}
