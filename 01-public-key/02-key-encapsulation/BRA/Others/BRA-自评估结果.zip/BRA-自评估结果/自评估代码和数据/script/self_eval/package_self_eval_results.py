#!/usr/bin/env python3

import argparse
import csv
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]

ALGORITHMS = [
    {
        "name": "BRA",
        "slug": "bra",
        "display": "BRA",
        "report_slug": "bra",
        "package_root": "BRA-自评估结果",
    },
    {
        "name": "BRQC",
        "slug": "brqc",
        "display": "BRQC",
        "report_slug": "brqc",
        "package_root": "BRQC-自评估结果",
    },
    {
        "name": "CMultiURAG",
        "slug": "cmultiurag",
        "display": "C-Multi-UR-AG",
        "report_slug": "cmultiurag",
        "package_root": "C-Multi-UR-AG-自评估结果",
    },
]

RESULT_FILES = [
    "environment.json",
    "kat.csv",
    "performance.csv",
    "raw_cycles.csv",
    "resources.csv",
    "sizes.csv",
    "commands.log",
]


def read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write_csv(path: Path, header: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def require_path(path: Path) -> None:
    if not path.exists():
        raise RuntimeError(f"required path is missing: {path.relative_to(ROOT)}")


def report_paths(algorithm: dict) -> tuple[Path, Path]:
    base = ROOT / "self_eval" / f"report_x86_{algorithm['report_slug']}"
    return base.with_suffix(".tex"), base.with_suffix(".pdf")


def validate_results(results_dir: Path) -> dict:
    for name in RESULT_FILES:
        require_path(results_dir / name)
    for algorithm in ALGORITHMS:
        tex_path, pdf_path = report_paths(algorithm)
        require_path(tex_path)
        require_path(pdf_path)

    headers = {}
    rows = {}
    for name in ["kat.csv", "performance.csv", "raw_cycles.csv", "resources.csv", "sizes.csv"]:
        header, data = read_csv(results_dir / name)
        headers[name] = header
        rows[name] = data

    if len(rows["kat.csv"]) != 18 or any(row["status"] != "PASS" for row in rows["kat.csv"]):
        raise RuntimeError("kat.csv must contain 18 PASS rows")
    if len(rows["performance.csv"]) != 90 or sum(int(row["failures"]) for row in rows["performance.csv"]) != 0:
        raise RuntimeError("performance.csv must contain 90 rows and zero failures")
    if len(rows["raw_cycles.csv"]) != 4500:
        raise RuntimeError("raw_cycles.csv must contain 4500 rows for the 50-sample full run")
    if len(rows["resources.csv"]) != 18:
        raise RuntimeError("resources.csv must contain 18 rows")
    if len(rows["sizes.csv"]) != 9:
        raise RuntimeError("sizes.csv must contain 9 rows")

    return {"headers": headers, "rows": rows}


def ignore_generated(_dir, names):
    ignored = {"__pycache__", "runner-bin", "output", "bin"}
    return {name for name in names if name in ignored or name.endswith(".pyc")}


def copy_file(src: Path, dst: Path) -> None:
    require_path(src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def copy_tree(src: Path, dst: Path) -> None:
    require_path(src)
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst, ignore=ignore_generated)


def filtered_rows(all_rows: dict, algorithm: dict) -> dict:
    candidate = algorithm["name"]
    return {
        "kat.csv": [row for row in all_rows["kat.csv"] if row["algorithm"] == candidate],
        "performance.csv": [
            row for row in all_rows["performance.csv"] if row["algorithm"] in {candidate, "Frodo", "HQC"}
        ],
        "raw_cycles.csv": [
            row for row in all_rows["raw_cycles.csv"] if row["algorithm"] in {candidate, "Frodo", "HQC"}
        ],
        "resources.csv": [row for row in all_rows["resources.csv"] if row["algorithm"] == candidate],
        "sizes.csv": [row for row in all_rows["sizes.csv"] if row["algorithm"] == candidate],
    }


def copy_filtered_results(results_dir: Path, dst: Path, algorithm: dict, validation: dict) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    copy_file(results_dir / "environment.json", dst / "environment.json")
    copy_file(results_dir / "commands.log", dst / "commands.log")
    rows = filtered_rows(validation["rows"], algorithm)
    for name, data in rows.items():
        write_csv(dst / name, validation["headers"][name], data)


def copy_self_eval_code_and_data(results_dir: Path, algorithm: dict, dst: Path, validation: dict) -> None:
    copy_file(ROOT / "script" / "self_eval" / "run_x86_self_eval.py", dst / "script" / "self_eval" / "run_x86_self_eval.py")
    copy_file(ROOT / "script" / "self_eval" / "package_self_eval_results.py", dst / "script" / "self_eval" / "package_self_eval_results.py")
    copy_file(ROOT / "test" / "self_eval" / "kem_runner.c", dst / "test" / "self_eval" / "kem_runner.c")
    copy_file(ROOT / "self_eval" / "README.md", dst / "self_eval" / "README.md")
    copy_filtered_results(results_dir, dst / "results" / "current", algorithm, validation)


def copy_candidate_source_and_vectors(algorithm: dict, dst: Path) -> None:
    iccs_root = ROOT / "build" / "packaging" / "iccs" / algorithm["slug"]
    copy_tree(iccs_root / "Implementations", dst / "Implementations")
    copy_tree(iccs_root / "Test_Vectors", dst / "Test_Vectors")


def copy_report(algorithm: dict, dst: Path) -> None:
    tex_path, pdf_path = report_paths(algorithm)
    copy_file(pdf_path, dst / pdf_path.name)
    copy_file(tex_path, dst / tex_path.name)


def copy_dependency_statement(dst: Path) -> None:
    copy_file(ROOT / "self_eval" / "Dependency_Statement.md", dst / "Dependency_Statement.md")


def write_package_readme(algorithm: dict, path: Path) -> None:
    text = f"""# {algorithm['display']} x86 Self-Evaluation Results

This archive contains the x86 self-evaluation materials for the
{algorithm['display']} key encapsulation mechanism.

The official report is the English LaTeX-generated PDF in `自评估报告/`.
The corresponding LaTeX source is included next to the PDF.

The `自评估代码和数据/results/current/` directory contains filtered
machine-readable evidence:

- `kat.csv`, `resources.csv`, and `sizes.csv` contain only {algorithm['display']} rows.
- `performance.csv` contains {algorithm['display']}, FrodoKEM, and HQC rows to
  reproduce the controlled baseline performance reference.
- `raw_cycles.csv` contains the corresponding per-sample inner-loop statistics:
  mean cycles, median cycles, standard deviation, and intra-sample CV. Warm-up
  samples are excluded.

FrodoKEM and HQC do not use the NGCC submission API in their official
implementations. Their rows are contextual baseline data and must not be
interpreted as a strict API-normalized fair comparison.

Temporary runner binaries are intentionally excluded from this archive.
"""
    path.write_text(text, encoding="utf-8")


def write_baseline_readme(path: Path) -> None:
    text = """# Baseline Performance Materials

FrodoKEM and HQC are included only as contextual performance baselines in
`performance.csv` and the English PDF report.

They are not part of the candidate KAT, resource-consumption, or
communication/storage-size claims. The source subsets here are the files used
by `script/self_eval/run_x86_self_eval.py` to build the baseline runners.
Because the official FrodoKEM and HQC implementations do not use the NGCC
submission API, these measurements are contextual baseline data and not a
strict API-normalized fair comparison.
"""
    path.write_text(text, encoding="utf-8")


def copy_baseline_materials(dst: Path) -> None:
    frodo_dst = dst / "FrodoKEM"
    copy_tree(ROOT / "baseline" / "FrodoKEM" / "FrodoKEM" / "src", frodo_dst / "FrodoKEM" / "src")
    copy_tree(ROOT / "baseline" / "FrodoKEM" / "FrodoKEM" / "tests", frodo_dst / "FrodoKEM" / "tests")
    copy_tree(ROOT / "baseline" / "FrodoKEM" / "common" / "aes", frodo_dst / "common" / "aes")
    copy_tree(ROOT / "baseline" / "FrodoKEM" / "common" / "sha3", frodo_dst / "common" / "sha3")
    for name in ["LICENSE", "README.md"]:
        src = ROOT / "baseline" / "FrodoKEM" / name
        if src.exists():
            copy_file(src, frodo_dst / name)
    src = ROOT / "baseline" / "FrodoKEM" / "FrodoKEM" / "README.md"
    if src.exists():
        copy_file(src, frodo_dst / "FrodoKEM" / "README.md")

    hqc_dst = dst / "HQC"
    copy_tree(ROOT / "baseline" / "HQC" / "src", hqc_dst / "src")
    copy_tree(ROOT / "baseline" / "HQC" / "lib" / "fips202", hqc_dst / "lib" / "fips202")
    for name in ["LICENSE", "README.md"]:
        src = ROOT / "baseline" / "HQC" / name
        if src.exists():
            copy_file(src, hqc_dst / name)

    write_baseline_readme(dst / "README.md")


def build_staging_tree(results_dir: Path, staging_root: Path, algorithm: dict, validation: dict) -> Path:
    package_root = staging_root / algorithm["package_root"]
    package_root.mkdir(parents=True)
    write_package_readme(algorithm, package_root / "README.md")
    copy_candidate_source_and_vectors(algorithm, package_root / "算法源代码")
    copy_self_eval_code_and_data(results_dir, algorithm, package_root / "自评估代码和数据", validation)
    copy_report(algorithm, package_root / "自评估报告")
    copy_dependency_statement(package_root / "依赖说明")
    copy_baseline_materials(package_root / "横向性能baseline材料")
    return package_root


def write_zip(package_root: Path, out_path: Path) -> None:
    if out_path.exists():
        out_path.unlink()
    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(package_root.rglob("*")):
            if path.is_file():
                rel = path.relative_to(package_root.parent)
                if "runner-bin" in rel.parts:
                    raise RuntimeError("runner-bin must not be included in the archive")
                if path.name == "report_x86.md":
                    raise RuntimeError("legacy Markdown report must not be included in the archive")
                archive.write(path, str(rel))


def write_manifest(out_dir: Path, written: list[Path]) -> None:
    manifest = {
        "archives": [str(path.relative_to(ROOT)) for path in written],
        "note": "Each archive is scoped to one candidate algorithm and includes FrodoKEM/HQC baseline material for performance comparison.",
    }
    (out_dir / "self_eval_package_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Package per-algorithm x86 self-evaluation evidence.")
    parser.add_argument("--results", default="self_eval/results/current")
    parser.add_argument("--out-dir", default=".")
    args = parser.parse_args()

    results_dir = (ROOT / args.results).resolve()
    out_dir = (ROOT / args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    validation = validate_results(results_dir)

    written = []
    for algorithm in ALGORITHMS:
        with tempfile.TemporaryDirectory(prefix=f"rbc-self-eval-{algorithm['slug']}-") as tmp:
            package_root = build_staging_tree(results_dir, Path(tmp), algorithm, validation)
            out_path = out_dir / f"{algorithm['package_root']}.zip"
            write_zip(package_root, out_path)
            written.append(out_path)
            print(out_path)

    write_manifest(out_dir, written)
    return 0


if __name__ == "__main__":
    sys.exit(main())
