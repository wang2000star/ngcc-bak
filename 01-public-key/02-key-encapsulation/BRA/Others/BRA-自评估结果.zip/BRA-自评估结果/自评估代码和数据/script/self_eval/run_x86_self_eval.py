#!/usr/bin/env python3

import argparse
import csv
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SEED = "".join(f"{i:02x}" for i in range(48))
REPORT_TIMEZONE = timezone(timedelta(hours=8))
DEFAULT_SAMPLES = 50
DEFAULT_REFERENCE_INNER_RUNS = 10
DEFAULT_OPTIMIZED_INNER_RUNS = 100
DEFAULT_WARMUP_RUNS = 5

ALGORITHMS = [
    {
        "name": "BRA",
        "slug": "bra",
        "caps": "BRA",
        "lower": "bra",
        "display": "BRA",
        "report_slug": "bra",
        "package_root": "BRA-自评估结果",
    },
    {
        "name": "BRQC",
        "slug": "brqc",
        "caps": "BRQC",
        "lower": "brqc",
        "display": "BRQC",
        "report_slug": "brqc",
        "package_root": "BRQC-自评估结果",
    },
    {
        "name": "CMultiURAG",
        "slug": "cmultiurag",
        "caps": "CMULTIURAG",
        "lower": "cmultiurag",
        "display": "C-Multi-UR-AG",
        "report_slug": "cmultiurag",
        "package_root": "C-Multi-UR-AG-自评估结果",
    },
]

LEVELS = [128, 256, 512]
SECURITY_LEVEL_BY_BITS = {128: "L1", 192: "L3", 256: "L5", 512: "L5+"}
SECURITY_COLUMNS = ["L1", "L3", "L5", "L5+"]
REPORT_ALGORITHMS = ["BRA", "BRQC", "CMultiURAG", "Frodo", "HQC"]
BASELINE_REPORT_ALGORITHMS = ["Frodo", "HQC"]
OPERATIONS = ["keygen", "encaps", "decaps"]

VERSIONS = [
    {
        "name": "Reference_Implementation",
        "label": "reference",
        "lib": "librbc-nist-ref.a",
        "guide_name": "参考实现版",
    },
    {
        "name": "Optimized_Implementation",
        "label": "optimized",
        "lib": "librbc-nist.a",
        "guide_name": "x86 性能优化版",
    },
]

PERFORMANCE_HEADER = [
    "algorithm",
    "family",
    "variant",
    "security_level",
    "security_bits",
    "version",
    "operation",
    "samples",
    "inner_runs",
    "warmup_runs",
    "failures",
    "cycles_mean",
    "cycles_median",
    "cycles_stddev",
    "intra_cv_mean_percent",
    "intra_cv_median_percent",
    "intra_cv_max_percent",
    "wall_seconds",
    "ops_per_second",
    "binary",
]

RAW_CYCLES_HEADER = [
    "algorithm",
    "family",
    "variant",
    "security_level",
    "security_bits",
    "version",
    "operation",
    "samples",
    "inner_runs",
    "warmup_runs",
    "sample_index",
    "sample_cycles_mean",
    "sample_cycles_median",
    "sample_cycles_stddev",
    "intra_cv_percent",
    "binary",
]

RESOURCE_HEADER = [
    "algorithm",
    "instance",
    "version",
    "text_bytes",
    "data_bytes",
    "bss_bytes",
    "static_total_bytes",
    "max_rss_kbytes",
    "binary",
]

KAT_HEADER = [
    "algorithm",
    "instance",
    "version",
    "implementation_dir",
    "expected_file",
    "generated_sha256",
    "expected_sha256",
    "bytes",
    "status",
]

SIZE_HEADER = [
    "algorithm",
    "instance",
    "public_key_bytes",
    "secret_key_bytes",
    "ciphertext_bytes",
    "shared_secret_bytes",
]


class Runner:
    def __init__(self, out_dir: Path, cpu: int):
        self.out_dir = out_dir
        self.cpu = str(cpu)
        self.commands_log = out_dir / "commands.log"
        self.commands_log.parent.mkdir(parents=True, exist_ok=True)
        self.commands_log.write_text("", encoding="utf-8")

    def log(self, message: str) -> None:
        with self.commands_log.open("a", encoding="utf-8") as handle:
            handle.write(message.rstrip() + "\n")

    def run(self, cmd, cwd: Path = ROOT, check: bool = True):
        display = " ".join(str(part) for part in cmd)
        self.log(f"$ (cd {cwd}) {display}")
        result = subprocess.run(
            [str(part) for part in cmd],
            cwd=str(cwd),
            text=True,
            capture_output=True,
        )
        if result.stdout:
            self.log(result.stdout)
        if result.stderr:
            self.log(result.stderr)
        if check and result.returncode != 0:
            raise RuntimeError(f"command failed ({result.returncode}): {display}")
        return result

    def taskset(self, cmd):
        return ["taskset", "-c", self.cpu] + list(cmd)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_first_line(cmd) -> str:
    try:
        result = subprocess.run(cmd, cwd=str(ROOT), text=True, capture_output=True, check=False)
        return (result.stdout or result.stderr).splitlines()[0].strip()
    except Exception:
        return ""


def effective_inner_runs(args, version_name: str) -> int:
    if getattr(args, "inner_runs", None) is not None:
        return args.inner_runs
    if version_name == "Reference_Implementation":
        return args.reference_inner_runs
    if version_name == "Optimized_Implementation":
        return args.optimized_inner_runs
    return args.reference_inner_runs


def collect_environment(args) -> dict:
    os_release = {}
    os_release_path = Path("/etc/os-release")
    if os_release_path.exists():
        for line in os_release_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                os_release[key] = value.strip().strip('"')

    cpu_model = ""
    cpu_flags = ""
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        for line in cpuinfo.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("model name") and not cpu_model:
                cpu_model = line.split(":", 1)[1].strip()
            if line.startswith("flags") and not cpu_flags:
                cpu_flags = line.split(":", 1)[1].strip()

    reference_inner_runs = effective_inner_runs(args, "Reference_Implementation")
    optimized_inner_runs = effective_inner_runs(args, "Optimized_Implementation")

    inner_runs_value = (
        reference_inner_runs
        if reference_inner_runs == optimized_inner_runs
        else f"Reference_Implementation={reference_inner_runs}; Optimized_Implementation={optimized_inner_runs}"
    )

    return {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "ended_at": None,
        "host": platform.node(),
        "machine": platform.machine(),
        "cpu_model": cpu_model,
        "cpu_flags": cpu_flags,
        "avx2_supported": "avx2" in cpu_flags.split(),
        "cpu_pinned": args.cpu,
        "os": os_release.get("PRETTY_NAME", platform.platform()),
        "kernel": platform.release(),
        "gcc": read_first_line(["gcc", "--version"]),
        "cmake": read_first_line(["cmake", "--version"]),
        "openssl": read_first_line(["openssl", "version"]),
        "python": sys.version.split()[0],
        "config": str(Path(args.config).resolve()),
        "samples": args.samples,
        "inner_runs": inner_runs_value,
        "reference_inner_runs": reference_inner_runs,
        "optimized_inner_runs": optimized_inner_runs,
        "warmup_runs": args.warmup_runs,
        "include_baseline": not getattr(args, "skip_baseline", False),
        "seed_hex": DEFAULT_SEED,
        "reference_compile_flags": "-std=c99 -Wpedantic -Wall -Wextra -O2",
        "optimized_compile_flags": "-O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -mpclmul -msse4.2 -maes -std=c99 -Wpedantic -Wall -Wextra -DSHAKE_TIMES4",
    }


def check_prerequisites(include_baseline: bool) -> None:
    required = [
        ROOT / "bin" / "librbc-nist.a",
        ROOT / "bin" / "librbc-nist-ref.a",
        ROOT / "bin" / "include" / "rbc.h",
        ROOT / "build" / "packaging" / "iccs",
    ]
    if include_baseline:
        required.extend(
            [
                ROOT / "baseline" / "FrodoKEM" / "FrodoKEM" / "src",
                ROOT / "baseline" / "FrodoKEM" / "FrodoKEM" / "tests" / "rng.c",
                ROOT / "baseline" / "HQC" / "src",
            ]
        )
    missing = [str(path.relative_to(ROOT)) for path in required if not path.exists()]
    if missing:
        raise RuntimeError(
            "missing build artifacts: "
            + ", ".join(missing)
            + ". Run `python -B rbc-lib.py config.yml` first."
        )


def write_csv(path: Path, header, rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=header)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def collect_sizes() -> list:
    rows = []
    for algorithm in ALGORITHMS:
        for level in LEVELS:
            prefix = f"{algorithm['caps']}_{level}"
            param_file = ROOT / "bin" / "include" / f"{algorithm['lower']}_{level}_parameters.h"
            content = param_file.read_text(encoding="utf-8", errors="ignore")

            def macro(name: str) -> int:
                match = re.search(rf"#define\s+{re.escape(prefix + '_' + name)}\s+([0-9]+)", content)
                if not match:
                    raise RuntimeError(f"macro not found: {prefix}_{name} in {param_file}")
                return int(match.group(1))

            instance = f"{algorithm['name']}-{level}"
            rows.append(
                {
                    "algorithm": algorithm["name"],
                    "instance": instance,
                    "public_key_bytes": macro("PUBLIC_KEY_BYTES"),
                    "secret_key_bytes": macro("SECRET_KEY_BYTES"),
                    "ciphertext_bytes": macro("CIPHERTEXT_BYTES"),
                    "shared_secret_bytes": macro("SHARED_SECRET_BYTES"),
                }
            )
    return rows


def base_compile_flags(version: dict, extra_optimized_flags=None) -> list:
    if version["label"] == "reference":
        return ["-std=gnu99", "-O2", "-Wpedantic", "-Wall", "-Wextra"]
    flags = [
        "-std=gnu99",
        "-O3",
        "-march=x86-64",
        "-mavx2",
        "-mtune=native",
        "-flto",
        "-fomit-frame-pointer",
        "-Wpedantic",
        "-Wall",
        "-Wextra",
    ]
    if extra_optimized_flags:
        flags.extend(extra_optimized_flags)
    return flags


def add_include_flags(cmd: list, include_dirs: list) -> None:
    for include_dir in include_dirs:
        cmd.extend(["-I", include_dir])


def source_files(directory: Path, pattern: str = "*.c") -> list:
    return sorted(directory.glob(pattern))


def new_binary_entry(
    algorithm: str,
    family: str,
    variant: str,
    security_bits: int,
    version: dict,
    binary: Path,
) -> dict:
    return {
        "algorithm": algorithm,
        "family": family,
        "variant": variant,
        "security_level": SECURITY_LEVEL_BY_BITS[security_bits],
        "security_bits": str(security_bits),
        "version": version["name"],
        "binary": binary,
    }


def compile_candidate_runners(runner: Runner, out_dir: Path) -> list:
    bin_dir = out_dir / "runner-bin"
    if bin_dir.exists():
        shutil.rmtree(bin_dir)
    bin_dir.mkdir(parents=True)

    binaries = []
    source = ROOT / "test" / "self_eval" / "kem_runner.c"
    include_dir = ROOT / "bin" / "include"

    for algorithm in ALGORITHMS:
        for level in LEVELS:
            instance = f"{algorithm['name']}-{level}"
            func_prefix = f"{algorithm['lower']}_{level}"
            macro_prefix = f"{algorithm['caps']}_{level}"
            for version in VERSIONS:
                binary = bin_dir / f"{algorithm['slug']}-{level}-{version['label']}"
                lib = ROOT / "bin" / version["lib"]
                cmd = [
                    "gcc",
                    "-std=gnu99",
                    "-O2",
                    "-Wpedantic",
                    "-Wall",
                    "-Wextra",
                    "-I",
                    include_dir,
                    "-DSELF_EVAL_HEADER=\"rbc.h\"",
                    "-DSELF_EVAL_USE_RANDOMBYTES_INIT",
                    f"-DSELF_EVAL_ALGORITHM=\"{algorithm['name']}\"",
                    f"-DSELF_EVAL_INSTANCE=\"{instance}\"",
                    f"-DSELF_EVAL_VERSION=\"{version['name']}\"",
                    f"-DSELF_EVAL_KEYGEN={func_prefix}_keygen",
                    f"-DSELF_EVAL_ENCAPS={func_prefix}_encaps",
                    f"-DSELF_EVAL_DECAPS={func_prefix}_decaps",
                    f"-DSELF_EVAL_PUBLIC_KEY_BYTES={macro_prefix}_PUBLIC_KEY_BYTES",
                    f"-DSELF_EVAL_SECRET_KEY_BYTES={macro_prefix}_SECRET_KEY_BYTES",
                    f"-DSELF_EVAL_CIPHERTEXT_BYTES={macro_prefix}_CIPHERTEXT_BYTES",
                    f"-DSELF_EVAL_SHARED_SECRET_BYTES={macro_prefix}_SHARED_SECRET_BYTES",
                    source,
                    lib,
                    "-lcrypto",
                    "-o",
                    binary,
                ]
                runner.run(cmd)
                binaries.append(
                    new_binary_entry(
                        algorithm["name"],
                        "candidate",
                        instance,
                        level,
                        version,
                        binary,
                    )
                )
    return binaries


def compile_frodo_runners(runner: Runner, bin_dir: Path) -> list:
    binaries = []
    source = ROOT / "test" / "self_eval" / "kem_runner.c"
    frodo_root = ROOT / "baseline" / "FrodoKEM"
    frodo_src = frodo_root / "FrodoKEM" / "src"
    frodo_tests = frodo_root / "FrodoKEM" / "tests"
    frodo_common = frodo_root / "common"
    include_dirs = [
        frodo_src,
        frodo_tests,
        frodo_common / "sha3",
        frodo_common / "aes",
    ]
    variants = [
        (640, 128, "api_frodo640.h", "crypto_kem_keypair_Frodo640", "crypto_kem_enc_Frodo640", "crypto_kem_dec_Frodo640"),
        (976, 192, "api_frodo976.h", "crypto_kem_keypair_Frodo976", "crypto_kem_enc_Frodo976", "crypto_kem_dec_Frodo976"),
        (1344, 256, "api_frodo1344.h", "crypto_kem_keypair_Frodo1344", "crypto_kem_enc_Frodo1344", "crypto_kem_dec_Frodo1344"),
    ]

    for variant, security_bits, header, keygen, encaps, decaps in variants:
        for version in VERSIONS:
            is_optimized = version["label"] == "optimized"
            binary = bin_dir / f"frodo-{variant}-{version['label']}"
            aes_source = frodo_common / "aes" / ("aes_ni.c" if is_optimized else "aes_c.c")
            sources = [
                source,
                frodo_src / f"frodo{variant}.c",
                frodo_src / "util.c",
                frodo_tests / "rng.c",
                frodo_common / "sha3" / "fips202.c",
                aes_source,
            ]
            cmd = ["gcc"]
            cmd.extend(base_compile_flags(version, ["-maes", "-msse2"]))
            add_include_flags(cmd, include_dirs)
            cmd.extend(
                [
                    "-D_AMD64_",
                    "-D_AES128_FOR_A_",
                    "-DNO_OPENSSL",
                    "-DNIX",
                    "-D_FAST_" if is_optimized else "-D_REFERENCE_",
                    f"-DSELF_EVAL_HEADER=\"{header}\"",
                    "-DSELF_EVAL_USE_RANDOMBYTES_INIT",
                    "-DSELF_EVAL_ALGORITHM=\"Frodo\"",
                    f"-DSELF_EVAL_INSTANCE=\"Frodo-{variant}\"",
                    f"-DSELF_EVAL_VERSION=\"{version['name']}\"",
                    f"-DSELF_EVAL_KEYGEN={keygen}",
                    f"-DSELF_EVAL_ENCAPS={encaps}",
                    f"-DSELF_EVAL_DECAPS={decaps}",
                    "-DSELF_EVAL_PUBLIC_KEY_BYTES=CRYPTO_PUBLICKEYBYTES",
                    "-DSELF_EVAL_SECRET_KEY_BYTES=CRYPTO_SECRETKEYBYTES",
                    "-DSELF_EVAL_CIPHERTEXT_BYTES=CRYPTO_CIPHERTEXTBYTES",
                    "-DSELF_EVAL_SHARED_SECRET_BYTES=CRYPTO_BYTES",
                ]
            )
            cmd.extend(sources)
            cmd.extend(["-lm", "-o", binary])
            runner.run(cmd)
            binaries.append(
                new_binary_entry("Frodo", "baseline", f"Frodo-{variant}", security_bits, version, binary)
            )
    return binaries


def compile_hqc_runners(runner: Runner, bin_dir: Path) -> list:
    binaries = []
    source = ROOT / "test" / "self_eval" / "kem_runner.c"
    hqc_root = ROOT / "baseline" / "HQC"
    hqc_src = hqc_root / "src"
    hqc_common = hqc_src / "common"
    hqc_ref = hqc_src / "ref"
    hqc_x86_common = hqc_src / "x86_64" / "common"
    hqc_x86_avx = hqc_src / "x86_64" / "avx256"
    hqc_fips202 = hqc_root / "lib" / "fips202"
    variants = [(1, 128), (3, 192), (5, 256)]
    common_sources = source_files(hqc_common)

    for variant, security_bits in variants:
        variant_dir = f"hqc-{variant}"
        for version in VERSIONS:
            is_optimized = version["label"] == "optimized"
            binary = bin_dir / f"hqc-{variant}-{version['label']}"
            if is_optimized:
                sources = (
                    [source]
                    + common_sources
                    + source_files(hqc_x86_common)
                    + source_files(hqc_x86_common / variant_dir)
                    + source_files(hqc_x86_avx)
                    + source_files(hqc_x86_avx / variant_dir)
                    + [hqc_fips202 / "fips202.c"]
                )
                include_dirs = [
                    hqc_common,
                    hqc_common / variant_dir,
                    hqc_x86_common,
                    hqc_x86_common / variant_dir,
                    hqc_x86_avx,
                    hqc_x86_avx / variant_dir,
                    hqc_fips202,
                ]
                arch_defs = ["-DHQC_ARCH_X86_64=1", "-DHQC_ARCH_X86_64_AVX256=1"]
                extra_flags = ["-mavx", "-mbmi", "-mpclmul", "-funroll-all-loops"]
            else:
                sources = (
                    [source]
                    + common_sources
                    + source_files(hqc_ref)
                    + source_files(hqc_ref / variant_dir)
                    + [hqc_fips202 / "fips202.c"]
                )
                include_dirs = [
                    hqc_common,
                    hqc_common / variant_dir,
                    hqc_ref,
                    hqc_ref / variant_dir,
                    hqc_fips202,
                ]
                arch_defs = ["-DHQC_ARCH_REF=1"]
                extra_flags = []

            cmd = ["gcc"]
            cmd.extend(base_compile_flags(version, extra_flags))
            add_include_flags(cmd, include_dirs)
            cmd.extend(
                arch_defs
                + [
                    f"-DSELF_EVAL_HEADER=\"api.h\"",
                    "-DSELF_EVAL_USE_HQC_PRNG_INIT",
                    "-DSELF_EVAL_ALGORITHM=\"HQC\"",
                    f"-DSELF_EVAL_INSTANCE=\"HQC-{variant}\"",
                    f"-DSELF_EVAL_VERSION=\"{version['name']}\"",
                    "-DSELF_EVAL_KEYGEN=crypto_kem_keypair",
                    "-DSELF_EVAL_ENCAPS=crypto_kem_enc",
                    "-DSELF_EVAL_DECAPS=crypto_kem_dec",
                    "-DSELF_EVAL_PUBLIC_KEY_BYTES=CRYPTO_PUBLICKEYBYTES",
                    "-DSELF_EVAL_SECRET_KEY_BYTES=CRYPTO_SECRETKEYBYTES",
                    "-DSELF_EVAL_CIPHERTEXT_BYTES=CRYPTO_CIPHERTEXTBYTES",
                    "-DSELF_EVAL_SHARED_SECRET_BYTES=CRYPTO_BYTES",
                ]
            )
            cmd.extend(sources)
            cmd.extend(["-o", binary])
            runner.run(cmd)
            binaries.append(new_binary_entry("HQC", "baseline", f"HQC-{variant}", security_bits, version, binary))
    return binaries


def compile_baseline_runners(runner: Runner, out_dir: Path) -> list:
    bin_dir = out_dir / "runner-bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    return compile_frodo_runners(runner, bin_dir) + compile_hqc_runners(runner, bin_dir)


def run_kat(runner: Runner) -> list:
    rows = []
    for algorithm in ALGORITHMS:
        for level in LEVELS:
            instance = f"{algorithm['name']}-{level}"
            target = instance
            expected = (
                ROOT
                / "build"
                / "packaging"
                / "iccs"
                / algorithm["slug"]
                / "Test_Vectors"
                / f"KAT_KEM_{instance}.txt"
            )
            expected_hash = sha256_file(expected)
            expected_bytes = expected.stat().st_size

            for version in VERSIONS:
                impl_dir = (
                    ROOT
                    / "build"
                    / "packaging"
                    / "iccs"
                    / algorithm["slug"]
                    / "Implementations"
                    / version["name"]
                    / instance
                )
                generated = impl_dir / "output" / f"KAT_KEM_{instance}.txt"
                status = "FAIL"
                generated_hash = ""
                try:
                    runner.run(runner.taskset(["make", f"{target}-kat"]), cwd=impl_dir)
                    runner.run(runner.taskset([f"./bin/{target}-kat"]), cwd=impl_dir)
                    if generated.exists():
                        generated_hash = sha256_file(generated)
                        if generated_hash == expected_hash and generated.read_bytes() == expected.read_bytes():
                            status = "PASS"
                finally:
                    shutil.rmtree(impl_dir / "output", ignore_errors=True)
                    shutil.rmtree(impl_dir / "bin", ignore_errors=True)

                rows.append(
                    {
                        "algorithm": algorithm["name"],
                        "instance": instance,
                        "version": version["name"],
                        "implementation_dir": str(impl_dir.relative_to(ROOT)),
                        "expected_file": str(expected.relative_to(ROOT)),
                        "generated_sha256": generated_hash,
                        "expected_sha256": expected_hash,
                        "bytes": expected_bytes,
                        "status": status,
                    }
                )
    return rows


def parse_runner_output(output: str, entry: dict, samples: int, inner_runs: int, warmup_runs: int) -> tuple[list, list]:
    rows = []
    raw_rows = []
    for line in output.splitlines():
        fields = next(csv.reader([line]))
        if fields and fields[0] == "SELF_EVAL":
            if len(fields) != 16:
                raise RuntimeError(f"unexpected runner output: {line}")
            rows.append(
                {
                    "algorithm": fields[1],
                    "family": entry["family"],
                    "variant": entry["variant"],
                    "security_level": entry["security_level"],
                    "security_bits": entry["security_bits"],
                    "version": fields[3],
                    "operation": fields[4],
                    "samples": fields[5],
                    "inner_runs": fields[6],
                    "warmup_runs": str(warmup_runs),
                    "failures": fields[7],
                    "cycles_mean": fields[8],
                    "cycles_median": fields[9],
                    "cycles_stddev": fields[10],
                    "intra_cv_mean_percent": fields[11],
                    "intra_cv_median_percent": fields[12],
                    "intra_cv_max_percent": fields[13],
                    "wall_seconds": fields[14],
                    "ops_per_second": fields[15],
                    "binary": str(entry["binary"].relative_to(ROOT)),
                }
            )
        elif fields and fields[0] == "SELF_EVAL_SAMPLE":
            if len(fields) != 10:
                raise RuntimeError(f"unexpected raw sample output: {line}")
            raw_rows.append(
                {
                    "algorithm": fields[1],
                    "family": entry["family"],
                    "variant": entry["variant"],
                    "security_level": entry["security_level"],
                    "security_bits": entry["security_bits"],
                    "version": fields[3],
                    "operation": fields[4],
                    "samples": str(samples),
                    "inner_runs": str(inner_runs),
                    "warmup_runs": str(warmup_runs),
                    "sample_index": fields[5],
                    "sample_cycles_mean": fields[6],
                    "sample_cycles_median": fields[7],
                    "sample_cycles_stddev": fields[8],
                    "intra_cv_percent": fields[9],
                    "binary": str(entry["binary"].relative_to(ROOT)),
                }
            )
    return rows, raw_rows


def run_performance(runner: Runner, binaries: list, args, performance_path: Path, raw_cycles_path: Path) -> list:
    rows = []
    raw_rows = []
    performance_path.parent.mkdir(parents=True, exist_ok=True)
    raw_cycles_path.parent.mkdir(parents=True, exist_ok=True)
    with performance_path.open("w", newline="", encoding="utf-8") as handle, raw_cycles_path.open(
        "w", newline="", encoding="utf-8"
    ) as raw_handle:
        writer = csv.DictWriter(handle, fieldnames=PERFORMANCE_HEADER)
        raw_writer = csv.DictWriter(raw_handle, fieldnames=RAW_CYCLES_HEADER)
        writer.writeheader()
        raw_writer.writeheader()
        for entry in binaries:
            inner_runs = effective_inner_runs(args, entry["version"])
            for operation in OPERATIONS:
                result = runner.run(
                    runner.taskset(
                        [
                            entry["binary"],
                            "--operation",
                            operation,
                            "--samples",
                            str(args.samples),
                            "--inner-runs",
                            str(inner_runs),
                            "--warmup-runs",
                            str(args.warmup_runs),
                            "--raw-samples",
                            "--seed",
                            DEFAULT_SEED,
                        ]
                    )
                )
                op_rows, sample_rows = parse_runner_output(
                    result.stdout, entry, args.samples, inner_runs, args.warmup_runs
                )
                if len(op_rows) != 1 or op_rows[0]["operation"] != operation:
                    raise RuntimeError(f"unexpected performance rows for {entry['binary']} {operation}")
                if len(sample_rows) != args.samples:
                    raise RuntimeError(
                        f"unexpected raw sample count for {entry['binary']} {operation}: {len(sample_rows)}"
                    )
                rows.extend(op_rows)
                raw_rows.extend(sample_rows)
                writer.writerow(op_rows[0])
                raw_writer.writerows(sample_rows)
                handle.flush()
                raw_handle.flush()
    return rows


def parse_size_output(output: str) -> dict:
    lines = [line.split() for line in output.splitlines() if line.strip()]
    if len(lines) < 2 or lines[0][:4] != ["text", "data", "bss", "dec"]:
        raise RuntimeError(f"unexpected size output: {output}")
    return {
        "text_bytes": int(lines[1][0]),
        "data_bytes": int(lines[1][1]),
        "bss_bytes": int(lines[1][2]),
        "static_total_bytes": int(lines[1][3]),
    }


def parse_max_rss(stderr: str) -> int:
    match = re.search(r"Maximum resident set size \(kbytes\):\s+([0-9]+)", stderr)
    if not match:
        return 0
    return int(match.group(1))


def run_resources(runner: Runner, binaries: list) -> list:
    rows = []
    for entry in binaries:
        size_result = runner.run(["size", "-B", entry["binary"]])
        size_values = parse_size_output(size_result.stdout)
        time_cmd = [
            "/usr/bin/time",
            "-v",
            "taskset",
            "-c",
            runner.cpu,
            entry["binary"],
            "--samples",
            "1",
            "--inner-runs",
            "1",
            "--seed",
            DEFAULT_SEED,
        ]
        time_result = runner.run(time_cmd, check=False)
        if time_result.returncode not in (0, 1):
            raise RuntimeError(f"resource run failed for {entry['binary']}")
        row = {
            "algorithm": entry["algorithm"],
            "instance": entry["variant"],
            "version": entry["version"],
            "max_rss_kbytes": parse_max_rss(time_result.stderr),
            "binary": str(entry["binary"].relative_to(ROOT)),
        }
        row.update(size_values)
        rows.append(row)
    return rows


def write_readme(self_eval_dir: Path) -> None:
    readme = """# x86 Self-Evaluation

This directory contains reproducible x86 self-evaluation evidence for the NGCC
KEM implementations in this repository.

Run the complete build first:

```bash
python -B rbc-lib.py config.yml
```

Then run the x86 self-evaluation:

```bash
python -B script/self_eval/run_x86_self_eval.py --config config.yml --out self_eval/results/current --samples 50 --reference-inner-runs 10 --optimized-inner-runs 100 --warmup-runs 5 --cpu 0
```

The default run also compiles and times the baseline FrodoKEM and HQC
implementations under `baseline/` for performance comparison. Use
`--skip-baseline` only when debugging the NGCC submission implementations alone.

The generated evidence is written to `self_eval/results/current/`:

- `environment.json`: hardware/software environment and test parameters.
- `kat.csv`: KAT comparison results for reference and optimized implementations.
- `performance.csv`: keygen, encaps and decaps timing results for NGCC
  candidates and baseline algorithms. The default command expands the
  algorithm-text benchmark scale to 50 independent samples while keeping 10
  inner runs per reference sample, 100 inner runs per optimized sample, and 5
  warm-up samples.
- `raw_cycles.csv`: one row per measured sample with inner-loop mean, median,
  standard deviation, and intra-sample CV; warm-up samples are excluded.
- `resources.csv`: static size and peak RSS results.
- `sizes.csv`: public key, secret key, ciphertext and shared secret sizes.
- `commands.log`: exact commands and raw command output.

The official English LaTeX/PDF reports are generated per candidate algorithm:

- `self_eval/report_x86_bra.tex` and `self_eval/report_x86_bra.pdf`
- `self_eval/report_x86_brqc.tex` and `self_eval/report_x86_brqc.pdf`
- `self_eval/report_x86_cmultiurag.tex` and `self_eval/report_x86_cmultiurag.pdf`

The legacy Markdown report, when present, is an auxiliary readable copy only.
"""
    (self_eval_dir / "README.md").write_text(readme, encoding="utf-8")


def write_dependency_statement(self_eval_dir: Path) -> None:
    statement = """# Dependency Statement

This self-evaluation uses the repository build system and the generated
`bin/` artifacts from `rbc-lib.py`.

## Build and Test Tools

- GCC: recorded in `self_eval/results/current/environment.json`.
- CMake: recorded in `self_eval/results/current/environment.json`.
- OpenSSL libcrypto: linked by the benchmark and self-evaluation harness.
- GNU `taskset`, `size`, and `/usr/bin/time`: used for CPU pinning and resource measurement.

## Cryptographic Support Code

- API_PKC auxiliary code: `drng.c/h`, `auxfunc.c/h`, KAT templates, and the KEM API wrappers are copied into the ICCS packaging tree.
- XKCP: Keccak/SHAKE sources are bundled under `lib/XKCP`; `lib/XKCP/README.md` records the upstream commit and borrowed Picnic files.
- Randomness for reproducible self-evaluation uses the NIST-style deterministic `randombytes_init` interface with a fixed 48-byte seed recorded in `environment.json`.
- FrodoKEM baseline performance uses the upstream KAT DRBG (`FrodoKEM/FrodoKEM/tests/rng.c`) with the same fixed 48-byte seed.
- HQC baseline performance uses the upstream SHAKE PRNG (`prng_init`) with the same fixed 48-byte seed.

## Implementation Versions

- `Reference_Implementation`: mapped to the generated `librbc-nist-ref.a` c64 build and ICCS Reference directories.
- `Optimized_Implementation`: mapped to the generated `librbc-nist.a` AVX2 build and ICCS Optimized directories.

## Baseline Algorithms

- FrodoKEM: `Frodo-640`, `Frodo-976`, and `Frodo-1344` from `baseline/FrodoKEM`.
- HQC: `HQC-1`, `HQC-3`, and `HQC-5` from `baseline/HQC`.
- Baseline algorithms are included only in `performance.csv` and the horizontal performance comparison tables. KAT, resource, and size evidence remain scoped to the NGCC candidate implementations.
"""
    (self_eval_dir / "Dependency_Statement.md").write_text(statement, encoding="utf-8")


def markdown_table(rows, columns, limit=None) -> str:
    selected = rows if limit is None else rows[:limit]
    header = "| " + " | ".join(columns) + " |"
    sep = "| " + " | ".join(["---"] * len(columns)) + " |"
    body = []
    for row in selected:
        body.append("| " + " | ".join(str(row.get(col, "")) for col in columns) + " |")
    return "\n".join([header, sep] + body)


def format_kcycles(row) -> str:
    if row is None:
        return "--"
    failures = int(row["failures"])
    if failures:
        return f"FAIL({failures})"
    key = "cycles_median" if row.get("version") == "Optimized_Implementation" else "cycles_mean"
    return f"{int(row[key]) / 1000.0:.1f}"


def performance_matrix(perf_rows: list, version: str, operation: str) -> str:
    index = {}
    for row in perf_rows:
        if row["version"] == version and row["operation"] == operation:
            index[(row["algorithm"], row["security_level"])] = row

    rows = []
    for algorithm in REPORT_ALGORITHMS:
        matrix_row = {"算法": algorithm}
        for column in SECURITY_COLUMNS:
            matrix_row[column] = format_kcycles(index.get((algorithm, column)))
        rows.append(matrix_row)
    return markdown_table(rows, ["算法"] + SECURITY_COLUMNS)


def variant_mapping_table(perf_rows: list) -> str:
    index = {}
    for row in perf_rows:
        index[(row["algorithm"], row["security_level"])] = row["variant"]

    rows = []
    for algorithm in REPORT_ALGORITHMS:
        mapping_row = {"算法": algorithm}
        for column in SECURITY_COLUMNS:
            mapping_row[column] = index.get((algorithm, column), "--")
        rows.append(mapping_row)
    return markdown_table(rows, ["算法"] + SECURITY_COLUMNS)


def performance_comparison_section(perf_rows: list) -> str:
    parts = [
        "## 5. 横向性能对比",
        "",
        "下列表格单位为 kcycles。参考实现行使用平均 CPU 周期；优化实现行使用 50 个正式样本的中位数 CPU 周期。`--` 表示该算法没有对应安全强度参数集；`FAIL(n)` 表示该项实测失败计数为 n。",
        "",
        "安全强度列对应的具体参数集如下：",
        "",
        variant_mapping_table(perf_rows),
        "",
        "对比边界：所有条目在同一机器、同一固定 CPU、同一 samples/inner_runs 和同一外层 runner 计时逻辑下测量；reference 与 optimized 分开列示。但 FrodoKEM 和 HQC 使用各自官方实现的 API/接口约定，并非 NGCC API，因此该结果只能作为受控 baseline 性能参考，不能解释为严格 API 归一化的公平竞赛。不同算法的安全强度类别也不是完全一一等价，`L5+` 仅当前 NGCC 512-bit 参数集提供数据。",
    ]

    op_titles = {"keygen": "KeyGen", "encaps": "Encaps", "decaps": "Decaps"}
    for version in [item["name"] for item in VERSIONS]:
        parts.extend(["", f"### {version}", ""])
        for operation in OPERATIONS:
            parts.extend([f"#### {op_titles[operation]}", "", performance_matrix(perf_rows, version, operation), ""])
    return "\n".join(parts).rstrip()


TEX_REPLACEMENTS = {
    "\\": r"\textbackslash{}",
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def tex_escape(value) -> str:
    text = "" if value is None else str(value)
    return "".join(TEX_REPLACEMENTS.get(ch, ch) for ch in text)


def texttt(value) -> str:
    return r"\texttt{" + tex_escape(value) + "}"


def latex_path(value) -> str:
    text = "" if value is None else str(value)
    return r"\path{" + text.replace("}", r"\}") + "}"


def format_report_time(value) -> str:
    if not value:
        return "not recorded"
    try:
        timestamp = str(value).replace("Z", "+00:00")
        parsed = datetime.fromisoformat(timestamp)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        local_time = parsed.astimezone(REPORT_TIMEZONE)
        return local_time.strftime("%Y-%m-%d %H:%M:%S UTC+8")
    except ValueError:
        return str(value)


def algorithm_meta(name: str) -> dict:
    for algorithm in ALGORITHMS:
        if algorithm["name"] == name:
            return algorithm
    raise KeyError(name)


def algorithm_display_name(name: str) -> str:
    if name == "Frodo":
        return "FrodoKEM"
    if name == "HQC":
        return "HQC"
    return algorithm_meta(name)["display"]


def variant_display(row: dict) -> str:
    variant = row["variant"] if "variant" in row else row.get("instance", "")
    if row["algorithm"] == "Frodo":
        return variant.replace("Frodo", "FrodoKEM", 1)
    if row["algorithm"] == "CMultiURAG":
        return variant.replace("CMultiURAG", "C-Multi-UR-AG", 1)
    return variant


def latex_monospace(value) -> str:
    return r"\texttt{" + tex_escape(value) + "}"


def split_fixed_width(value, width: int) -> list[str]:
    text = "" if value is None else str(value)
    return [text[i : i + width] for i in range(0, len(text), width)] or [""]


def split_flags(value, width: int = 82) -> list[str]:
    tokens = str(value or "").split()
    lines = []
    current = ""
    for token in tokens:
        candidate = f"{current} {token}".strip()
        if current and len(candidate) > width:
            lines.append(current)
            current = token
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines or [""]


def latex_monospace_block(lines: list[str], font_size: str = r"\small") -> str:
    body = [tex_escape(line) + r"\par" for line in lines]
    return "\n".join(
        [
            r"\begin{center}",
            r"\begin{minipage}{0.94\linewidth}",
            font_size,
            r"\ttfamily",
            r"\raggedright",
            *body,
            r"\end{minipage}",
            r"\end{center}",
        ]
    )


def latex_table(
    headers: list,
    rows: list,
    spec: str,
    font_size: str | None = None,
    raw_columns: set[int] | None = None,
) -> str:
    raw_columns = raw_columns or set()

    def cell(value, index: int) -> str:
        if index in raw_columns:
            return str(value)
        if str(value) == "--":
            return r"\texttt{--}"
        return tex_escape(value)

    lines = [r"\begin{center}"]
    if font_size:
        lines.append(font_size)
    lines.extend(
        [
            r"\begin{tabular}{" + spec + "}",
            r"\toprule",
            " & ".join(tex_escape(header) for header in headers) + r" \\",
            r"\midrule",
        ]
    )
    for row in rows:
        if isinstance(row, dict):
            values = [row.get(header, "") for header in headers]
        else:
            values = list(row)
        lines.append(" & ".join(cell(value, index) for index, value in enumerate(values)) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{center}"])
    return "\n".join(lines)


def latex_format_kcycles(row) -> str:
    if row is None:
        return "--"
    failures = int(row["failures"])
    if failures:
        return f"FAIL({failures})"
    key = "cycles_median" if row.get("version") == "Optimized_Implementation" else "cycles_mean"
    return f"{int(row[key]) / 1000.0:.1f}"


def inner_runs_report_sentence(env: dict) -> str:
    reference_inner_runs = str(env.get("reference_inner_runs"))
    optimized_inner_runs = str(env.get("optimized_inner_runs"))
    if reference_inner_runs == optimized_inner_runs:
        return (
            f"Both reference and optimized implementation rows use {reference_inner_runs} "
            "inner runs per sample."
        )
    return (
        f"Reference implementation rows use {reference_inner_runs} inner runs per sample, "
        f"while optimized implementation rows use {optimized_inner_runs} inner runs per sample."
    )


def zh_inner_runs_report_sentence(env: dict) -> str:
    reference_inner_runs = str(env.get("reference_inner_runs"))
    optimized_inner_runs = str(env.get("optimized_inner_runs"))
    if reference_inner_runs == optimized_inner_runs:
        return f"参考实现和优化实现均为每个样本 {reference_inner_runs} 次 inner run。"
    return (
        f"参考实现每个样本 {reference_inner_runs} 次 inner run，"
        f"优化实现每个样本 {optimized_inner_runs} 次 inner run。"
    )


def latex_variant_mapping_rows(perf_rows: list) -> list:
    index = {}
    for row in perf_rows:
        index[(row["algorithm"], row["security_level"])] = variant_display(row)

    rows = []
    for algorithm in report_row_algorithms(perf_rows):
        rows.append([algorithm_display_name(algorithm)] + [index.get((algorithm, level), "--") for level in SECURITY_COLUMNS])
    return rows


def report_row_algorithms(perf_rows: list) -> list:
    candidates = sorted({row["algorithm"] for row in perf_rows if row["family"] == "candidate"})
    if len(candidates) != 1:
        raise RuntimeError(f"expected one candidate algorithm in report rows, got {candidates}")
    return candidates + BASELINE_REPORT_ALGORITHMS


def latex_performance_rows(perf_rows: list, version: str, operation: str) -> list:
    index = {}
    for row in perf_rows:
        if row["version"] == version and row["operation"] == operation:
            index[(row["algorithm"], row["security_level"])] = row

    rows = []
    for algorithm in report_row_algorithms(perf_rows):
        rows.append(
            [algorithm_display_name(algorithm)]
            + [latex_format_kcycles(index.get((algorithm, level))) for level in SECURITY_COLUMNS]
        )
    return rows


def latex_version_title(version: str) -> str:
    if version == "Reference_Implementation":
        return "Reference Implementation"
    if version == "Optimized_Implementation":
        return "Optimized Implementation"
    return version.replace("_", " ")


def latex_version_short(version: str) -> str:
    if version == "Reference_Implementation":
        return "Reference"
    if version == "Optimized_Implementation":
        return "Optimized"
    return version.replace("_", " ")


def latex_operation_title(operation: str) -> str:
    return {"keygen": "KeyGen", "encaps": "Encapsulation", "decaps": "Decapsulation"}[operation]


def filter_report_rows(algorithm: dict, kat_rows: list, perf_rows: list, resource_rows: list, size_rows: list):
    candidate = algorithm["name"]
    report_kat = [row for row in kat_rows if row["algorithm"] == candidate]
    report_perf = [row for row in perf_rows if row["algorithm"] in {candidate, "Frodo", "HQC"}]
    report_resource = [row for row in resource_rows if row["algorithm"] == candidate]
    report_size = [row for row in size_rows if row["algorithm"] == candidate]
    return report_kat, report_perf, report_resource, report_size


def kat_summary_rows(kat_rows: list) -> list:
    by_instance = {}
    for row in kat_rows:
        by_instance.setdefault(row["instance"], {})[row["version"]] = row
    rows = []
    for instance in sorted(by_instance):
        versions = by_instance[instance]
        ref = versions.get("Reference_Implementation", {})
        opt = versions.get("Optimized_Implementation", {})
        algorithm = ref.get("algorithm", opt.get("algorithm", ""))
        rows.append(
            [
                variant_display({"algorithm": algorithm, "variant": instance}),
                ref.get("status", "--"),
                opt.get("status", "--"),
                ref.get("bytes", opt.get("bytes", "--")),
            ]
        )
    return rows


def kat_detail_rows(kat_rows: list) -> list:
    return [
        [
            variant_display({"algorithm": row["algorithm"], "variant": row["instance"]}),
            latex_version_short(row["version"]),
            row["status"],
            row["bytes"],
            latex_monospace(row["expected_sha256"][:16]),
            latex_monospace(row["generated_sha256"][:16]),
        ]
        for row in kat_rows
    ]


def resource_summary_rows(resource_rows: list) -> list:
    return [
        [
            variant_display({"algorithm": row["algorithm"], "variant": row["instance"]}),
            latex_version_short(row["version"]),
            row["text_bytes"],
            row["data_bytes"],
            row["bss_bytes"],
            row["static_total_bytes"],
            row["max_rss_kbytes"],
        ]
        for row in resource_rows
    ]


def size_summary_rows(size_rows: list) -> list:
    return [
        [
            variant_display({"algorithm": row["algorithm"], "variant": row["instance"]}),
            row["public_key_bytes"],
            row["secret_key_bytes"],
            row["ciphertext_bytes"],
            row["shared_secret_bytes"],
        ]
        for row in size_rows
    ]


def write_latex_report(
    self_eval_dir: Path,
    algorithm: dict,
    env: dict,
    kat_rows: list,
    perf_rows: list,
    resource_rows: list,
    size_rows: list,
) -> Path:
    kat_pass = sum(1 for row in kat_rows if row["status"] == "PASS")
    kat_fail = len(kat_rows) - kat_pass
    perf_fail = sum(int(row["failures"]) for row in perf_rows)
    display_name = algorithm["display"]
    report_name = f"report_x86_{algorithm['report_slug']}"
    inner_runs_sentence = inner_runs_report_sentence(env)

    performance_parts = [
        r"\section{Baseline Performance Reference with FrodoKEM and HQC}",
        f"This section provides a controlled baseline performance reference for {tex_escape(display_name)} against FrodoKEM and HQC. It is not a strict NGCC API fair comparison: the candidate implementation is evaluated through the generated NGCC submission API wrappers, while the FrodoKEM and HQC rows use their official implementation API and source-interface conventions adapted to the common timing runner.",
        "",
        "The measurements were collected on the same host, pinned to the same CPU, using the same outer measurement runner, operation definitions, sampling parameters, and fixed seed. Reference and optimized implementations are reported separately. Reference tables report mean CPU cycles in kcycles; optimized tables report median CPU cycles in kcycles. These results should therefore be read as contextual baseline evidence, not as a fully API-normalized competition result.",
        "",
        r"Missing cells are shown as \texttt{--}. No interpolation or extrapolation is applied. The L5+ column is populated only by the NGCC 512-bit candidate parameter sets.",
        "",
        r"\subsection{Security-Level Mapping}",
        latex_table(["Algorithm"] + SECURITY_COLUMNS, latex_variant_mapping_rows(perf_rows), r"@{}ccccc@{}", font_size=r"\small"),
    ]
    for version in [item["name"] for item in VERSIONS]:
        performance_parts.extend(["", rf"\subsection{{{tex_escape(latex_version_title(version))}}}"])
        for operation in OPERATIONS:
            performance_parts.extend(
                [
                    "",
                    rf"\subsubsection{{{tex_escape(latex_operation_title(operation))}}}",
                    latex_table(
                        ["Algorithm"] + SECURITY_COLUMNS,
                        latex_performance_rows(perf_rows, version, operation),
                        r"@{}ccccc@{}",
                        font_size=r"\small",
                    ),
                ]
            )
    performance_latex = "\n".join(performance_parts)

    latex = rf"""\documentclass[11pt,a4paper]{{article}}
\usepackage[margin=0.78in]{{geometry}}
\usepackage{{array}}
\usepackage{{booktabs}}
\usepackage{{enumitem}}
\usepackage{{hyperref}}
\usepackage{{xcolor}}
\hypersetup{{colorlinks=true,linkcolor=blue,urlcolor=blue}}
\setlength{{\tabcolsep}}{{4pt}}
\renewcommand{{\arraystretch}}{{1.12}}
\emergencystretch=2em
\setlist{{nosep,leftmargin=*}}
\title{{x86 Self-Evaluation Report for {tex_escape(display_name)}}}
\author{{NGCC KEM Implementation Evidence}}
\date{{Generated from reproducible local evidence}}

\begin{{document}}
\maketitle

\section{{Executive Summary}}
This report records the x86 self-evaluation evidence for the {tex_escape(display_name)} key encapsulation mechanism. It covers functional correctness, performance, resource consumption, communication and storage sizes, and a constrained baseline performance reference against FrodoKEM and HQC.

The functional KAT status is {kat_pass} PASS and {kat_fail} FAIL across {len(kat_rows)} candidate implementation checks. The performance failure count is {perf_fail}. Raw machine-readable evidence is stored under {latex_path('self_eval/results/current')}.

\section{{Algorithm and Implementation Scope}}
\begin{{itemize}}
\item Algorithm category: public-key cryptography / key encapsulation mechanism.
\item Candidate algorithm: {tex_escape(display_name)}.
\item Candidate security strengths: 128-bit, 256-bit, and 512-bit classical security claims.
\item Candidate implementation versions: Reference Implementation and x86 Optimized Implementation.
\item Baseline algorithms for contextual performance reference only: FrodoKEM and HQC.
\item Baseline comparison columns: L1, L3, L5, and L5+.
\end{{itemize}}

\section{{Evaluation Environment}}
\begin{{itemize}}
\item CPU: {tex_escape(env.get('cpu_model'))}
\item Pinned CPU: {tex_escape(env.get('cpu_pinned'))}
\item AVX2 supported: {tex_escape(env.get('avx2_supported'))}
\item Operating system: {tex_escape(env.get('os'))}
\item Kernel: {tex_escape(env.get('kernel'))}
\item GCC: {tex_escape(env.get('gcc'))}
\item CMake: {tex_escape(env.get('cmake'))}
\item OpenSSL: {tex_escape(env.get('openssl'))}
\item Python: {tex_escape(env.get('python'))}
\item Test start time: {tex_escape(format_report_time(env.get('started_at')))}
\item Test end time: {tex_escape(format_report_time(env.get('ended_at')))}
\item Samples: {tex_escape(env.get('samples'))}
\item Inner runs: {tex_escape(env.get('inner_runs'))}
\item Warm-up runs: {tex_escape(env.get('warmup_runs'))}
\end{{itemize}}

\noindent Fixed seed:
{latex_monospace_block(split_fixed_width(env.get('seed_hex'), 48))}

\section{{Build Configuration and Target Instruction Sets}}
Reference implementation compile flags:
{latex_monospace_block(split_flags(env.get('reference_compile_flags')))}

x86 optimized implementation compile flags:
{latex_monospace_block(split_flags(env.get('optimized_compile_flags')))}

The optimized candidate implementation uses the x86-64 and AVX2 target baseline. The actual build also keeps the additional target instruction flags required by the implementation, including PCLMUL, SSE4.2, and AES. FrodoKEM and HQC baseline runners are compiled from their upstream baseline source subsets using the same outer self-evaluation runner and fixed seed interface, but they retain their official implementation API and source-interface conventions rather than the NGCC submission API.

\section{{Functional Correctness Tests}}
KAT validation covers the three {tex_escape(display_name)} security strengths and two implementation versions. Generated KAT files are compared against the packaged test vectors by SHA-256 and byte-level equality.

{latex_table(["Instance", "Reference", "Optimized", "Vector bytes"], kat_summary_rows(kat_rows), r"@{}cccc@{}")}

\section{{Performance Evaluation}}
The performance CSV contains key generation, encapsulation, and decapsulation timing rows. Each row records samples, inner runs, warm-up runs, failure count, mean cycles, median cycles, standard deviation, wall time, and operations per second. The current run uses {tex_escape(env.get('samples'))} independent measured samples after {tex_escape(env.get('warmup_runs'))} warm-up samples. {tex_escape(inner_runs_sentence)}

The reporting statistic follows the algorithm-text convention. Reference implementation rows report arithmetic mean cycles because each measured sample is sufficiently long. Optimized implementation rows report median cycles because WSL 2 leaves Turbo Boost active, and rare slow samples may inflate the arithmetic mean of short-running optimized operations. CV is retained only as auxiliary diagnostic evidence in {latex_path('self_eval/results/current/raw_cycles.csv')}.

{performance_latex}

\section{{Resource Consumption}}
Static memory is measured with {texttt('size -B')}. Peak resident memory is measured using {texttt('/usr/bin/time -v')}. Resource consumption is reported for NGCC candidate implementations only; FrodoKEM and HQC are included only in the performance comparison section.

{latex_table(["Instance", "Version", "Text", "Data", "BSS", "Static", "RSS KB"], resource_summary_rows(resource_rows), r"@{}ccccccc@{}", font_size=r"\small")}

\section{{Communication and Storage Sizes}}
The size evidence is extracted from generated parameter macros. It covers public key, secret key, ciphertext, and shared-secret sizes for the NGCC candidate KEM instances only.

{latex_table(["Instance", "Public key", "Secret key", "Ciphertext", "Shared secret"], size_summary_rows(size_rows), r"@{}ccccc@{}")}

\section{{Reproducibility Evidence Index}}
\begin{{itemize}}
\item Environment: {latex_path('self_eval/results/current/environment.json')}
\item Functional correctness: {latex_path('self_eval/results/current/kat.csv')}
\item Performance: {latex_path('self_eval/results/current/performance.csv')}
\item Raw per-sample inner-loop statistics: {latex_path('self_eval/results/current/raw_cycles.csv')}
\item Resource consumption: {latex_path('self_eval/results/current/resources.csv')}
\item Communication and storage sizes: {latex_path('self_eval/results/current/sizes.csv')}
\item Command log: {latex_path('self_eval/results/current/commands.log')}
\item Self-evaluation script: {latex_path('script/self_eval/run_x86_self_eval.py')}
\item Measurement runner: {latex_path('test/self_eval/kem_runner.c')}
\end{{itemize}}

\section{{Limitations and Notes}}
\begin{{itemize}}
\item FrodoKEM and HQC are baselines for contextual performance reference only; they are not part of the NGCC candidate KAT, resource, or size claims.
\item The FrodoKEM and HQC baseline rows are not a strict NGCC API fair comparison, because their official implementations do not use the NGCC submission API used by the candidate packages.
\item The L1, L3, L5, and L5+ columns are comparison categories. They do not imply that all schemes have identical security margins within a column.
\item The L5+ column is available only for the candidate 512-bit parameter sets in this repository.
\item The default timing configuration expands the algorithm-text benchmark scale to 50 independent measured samples while keeping 10 inner runs per reference sample, 100 inner runs per optimized sample, and 5 warm-up samples.
\item Turbo Boost is not controlled in the WSL 2 environment. Optimized performance entries therefore use the median rather than the arithmetic mean.
\item This report covers x86 engineering self-evaluation evidence. Signed algorithm-basic-information and intellectual-property declaration PDFs are separate submission materials.
\end{{itemize}}

\appendix
\section{{Detailed KAT Evidence}}
{latex_table(["Instance", "Version", "Status", "Bytes", "Expected SHA256", "Generated SHA256"], kat_detail_rows(kat_rows), r"@{}cccccc@{}", font_size=r"\small", raw_columns={4, 5})}

\end{{document}}
"""
    tex_path = self_eval_dir / f"{report_name}.tex"
    tex_path.write_text(latex, encoding="utf-8")
    return tex_path


def compile_latex_report_pdf(runner: Runner, self_eval_dir: Path, tex_path: Path) -> Path:
    compiler = shutil.which("xelatex") or shutil.which("pdflatex")
    if compiler is None:
        raise RuntimeError("xelatex or pdflatex is required to build self-evaluation report PDFs")

    pdf_path = tex_path.with_suffix(".pdf")
    with tempfile.TemporaryDirectory(prefix="rbc-self-eval-tex-") as tmp:
        tmp_dir = Path(tmp)
        runner.run(
            [
                compiler,
                "-interaction=nonstopmode",
                "-halt-on-error",
                "-output-directory",
                tmp_dir,
                tex_path.name,
            ],
            cwd=self_eval_dir,
        )
        generated = tmp_dir / pdf_path.name
        if not generated.exists():
            raise RuntimeError(f"LaTeX did not produce {pdf_path.name}")
        shutil.copy2(generated, pdf_path)
    return pdf_path


def write_report(
    self_eval_dir: Path,
    env: dict,
    kat_rows: list,
    perf_rows: list,
    resource_rows: list,
    size_rows: list,
    runner: Runner | None = None,
) -> None:
    kat_pass = sum(1 for row in kat_rows if row["status"] == "PASS")
    kat_fail = len(kat_rows) - kat_pass
    perf_fail = sum(int(row["failures"]) for row in perf_rows)
    baseline_enabled = env.get("include_baseline")
    zh_inner_runs_sentence = zh_inner_runs_report_sentence(env)

    report = f"""# 新一代商用密码算法 x86 自评估报告

## 1. 基本信息

- 算法类别：公钥密码算法 / 密钥封装机制
- 算法名称：BRA、BRQC、CMultiURAG
- 横向性能 baseline：FrodoKEM、HQC（仅性能对比）
- 实现版本：参考实现版、x86 性能优化版
- 参数集/安全级别：128、256、512 比特经典安全强度
- 横向对比安全强度列：L1、L3、L5、L5+
- 测试开始时间：{format_report_time(env.get('started_at'))}
- 测试结束时间：{format_report_time(env.get('ended_at'))}

## 2. 评估环境信息

- CPU：{env.get('cpu_model')}
- 固定测试 CPU：{env.get('cpu_pinned')}
- AVX2 支持：{env.get('avx2_supported')}
- 操作系统：{env.get('os')}
- 内核版本：{env.get('kernel')}
- 编译器：{env.get('gcc')}
- 构建工具：{env.get('cmake')}
- OpenSSL：{env.get('openssl')}
- Python：{env.get('python')}
- 纳入 baseline 性能对比：{baseline_enabled}
- Warm-up runs：{env.get('warmup_runs')}

参考实现编译参数：

```text
{env.get('reference_compile_flags')}
```

x86 性能优化版编译参数：

```text
{env.get('optimized_compile_flags')}
```

## 3. 功能测试

KAT 测试覆盖 3 个算法、3 个安全强度等级、2 个实现版本，共 {len(kat_rows)} 项。

- PASS：{kat_pass}
- FAIL：{kat_fail}
- 原始证据：`self_eval/results/current/kat.csv`

{markdown_table(kat_rows, ['algorithm', 'instance', 'version', 'status', 'bytes'])}

## 4. 性能测试

性能测试使用固定 48 字节种子，单核运行。每项操作 samples={env.get('samples')}，inner_runs={env.get('inner_runs')}，warmup_runs={env.get('warmup_runs')}。
当前默认口径在算法文本 benchmark 的 inner-run 设置基础上扩展为 50 个正式测量样本，正式测量前执行 {env.get('warmup_runs')} 个 warm-up 样本，{zh_inner_runs_sentence}
cycles 为每次操作的 CPU 周期统计，ops/s 基于实际 wall time 计算。
`performance.csv` 同时记录 NGCC candidate 和 baseline，其中 `family` 字段区分 `candidate` 与 `baseline`。
`raw_cycles.csv` 记录每个正式测量样本内部 inner-loop 的 mean/median/stddev/intra-sample CV，不包含 warm-up 样本。
性能表统计量沿用算法文本口径：参考实现样本运行时间较长，报告算术平均 cycles；优化实现短操作可能受 WSL2/Turbo Boost 少数慢样本影响而抬高平均值，因此报告 50 个正式样本的中位数 cycles。CV 仅作为辅助诊断证据保留在 `raw_cycles.csv`。

- 失败计数总和：{perf_fail}
- 原始证据：`self_eval/results/current/performance.csv`

{performance_comparison_section(perf_rows)}

## 6. 资源消耗测试

静态内存通过 `size -B` 统计 text/data/bss；峰值内存通过 `/usr/bin/time -v` 的 maximum resident set size 统计。
资源消耗统计只覆盖 NGCC candidate 实现，不包含 baseline 算法。

- 原始证据：`self_eval/results/current/resources.csv`

{markdown_table(resource_rows, ['algorithm', 'instance', 'version', 'text_bytes', 'data_bytes', 'bss_bytes', 'static_total_bytes', 'max_rss_kbytes'])}

## 7. 传输与存储开销测试

尺寸数据来自生成头文件中的公开参数宏。
尺寸统计只覆盖 NGCC candidate 实现，不包含 baseline 算法。

- 原始证据：`self_eval/results/current/sizes.csv`

{markdown_table(size_rows, ['algorithm', 'instance', 'public_key_bytes', 'secret_key_bytes', 'ciphertext_bytes', 'shared_secret_bytes'])}

## 8. 原始证据索引

- 测试环境：`self_eval/results/current/environment.json`
- 功能测试：`self_eval/results/current/kat.csv`
- 性能测试：`self_eval/results/current/performance.csv`
- 逐样本 inner-loop 统计：`self_eval/results/current/raw_cycles.csv`
- 资源消耗：`self_eval/results/current/resources.csv`
- 尺寸开销：`self_eval/results/current/sizes.csv`
- 命令日志：`self_eval/results/current/commands.log`

## 9. 说明

本报告只覆盖《自评估指引》中的 x86 工程自评估材料。算法基本信息签字文件、知识产权声明签字文件不属于本报告范围。
"""
    (self_eval_dir / "report_x86.md").write_text(report, encoding="utf-8")
    for algorithm in ALGORITHMS:
        report_kat, report_perf, report_resource, report_size = filter_report_rows(
            algorithm, kat_rows, perf_rows, resource_rows, size_rows
        )
        tex_path = write_latex_report(
            self_eval_dir,
            algorithm,
            env,
            report_kat,
            report_perf,
            report_resource,
            report_size,
        )
        if runner is not None:
            compile_latex_report_pdf(runner, self_eval_dir, tex_path)


def cleanup_packaging_outputs() -> None:
    packaging = ROOT / "build" / "packaging" / "iccs"
    if not packaging.exists():
        return
    for path in packaging.rglob("output"):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
    for path in packaging.rglob("bin"):
        if path.is_dir() and "Implementations" in path.parts:
            shutil.rmtree(path, ignore_errors=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run x86 self-evaluation for NGCC KEM implementations.")
    parser.add_argument("--config", default="config.yml")
    parser.add_argument("--out", default="self_eval/results/current")
    parser.add_argument("--samples", type=int, default=DEFAULT_SAMPLES)
    parser.add_argument(
        "--inner-runs",
        type=int,
        default=None,
        help="Override both reference and optimized inner-run counts.",
    )
    parser.add_argument("--reference-inner-runs", type=int, default=DEFAULT_REFERENCE_INNER_RUNS)
    parser.add_argument("--optimized-inner-runs", type=int, default=DEFAULT_OPTIMIZED_INNER_RUNS)
    parser.add_argument("--warmup-runs", type=int, default=DEFAULT_WARMUP_RUNS)
    parser.add_argument("--cpu", type=int, default=0)
    parser.add_argument("--skip-baseline", action="store_true", help="Only run NGCC candidate self-evaluation.")
    args = parser.parse_args()
    if args.samples <= 0:
        raise RuntimeError("--samples must be positive")
    if args.inner_runs is not None and args.inner_runs <= 0:
        raise RuntimeError("--inner-runs must be positive")
    if args.reference_inner_runs <= 0:
        raise RuntimeError("--reference-inner-runs must be positive")
    if args.optimized_inner_runs <= 0:
        raise RuntimeError("--optimized-inner-runs must be positive")
    if args.warmup_runs < 0:
        raise RuntimeError("--warmup-runs must be non-negative")

    out_dir = (ROOT / args.out).resolve()
    self_eval_dir = ROOT / "self_eval"
    out_dir.mkdir(parents=True, exist_ok=True)

    runner = Runner(out_dir, args.cpu)
    check_prerequisites(include_baseline=not args.skip_baseline)

    env = collect_environment(args)
    (out_dir / "environment.json").write_text(json.dumps(env, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    write_readme(self_eval_dir)
    write_dependency_statement(self_eval_dir)

    size_rows = collect_sizes()
    write_csv(out_dir / "sizes.csv", SIZE_HEADER, size_rows)

    kat_rows = run_kat(runner)
    write_csv(out_dir / "kat.csv", KAT_HEADER, kat_rows)

    candidate_binaries = compile_candidate_runners(runner, out_dir)
    baseline_binaries = [] if args.skip_baseline else compile_baseline_runners(runner, out_dir)
    perf_rows = run_performance(
        runner,
        candidate_binaries + baseline_binaries,
        args,
        out_dir / "performance.csv",
        out_dir / "raw_cycles.csv",
    )

    resource_rows = run_resources(runner, candidate_binaries)
    write_csv(out_dir / "resources.csv", RESOURCE_HEADER, resource_rows)

    cleanup_packaging_outputs()

    env["ended_at"] = datetime.now(timezone.utc).isoformat()
    (out_dir / "environment.json").write_text(json.dumps(env, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_report(self_eval_dir, env, kat_rows, perf_rows, resource_rows, size_rows, runner=runner)

    if any(row["status"] != "PASS" for row in kat_rows):
        return 1
    if any(int(row["failures"]) != 0 for row in perf_rows):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
