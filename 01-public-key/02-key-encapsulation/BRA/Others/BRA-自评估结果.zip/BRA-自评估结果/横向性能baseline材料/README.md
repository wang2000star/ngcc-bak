# Baseline Performance Materials

FrodoKEM and HQC are included only as contextual performance baselines in
`performance.csv` and the English PDF report.

They are not part of the candidate KAT, resource-consumption, or
communication/storage-size claims. The source subsets here are the files used
by `script/self_eval/run_x86_self_eval.py` to build the baseline runners.
Because the official FrodoKEM and HQC implementations do not use the NGCC
submission API, these measurements are contextual baseline data and not a
strict API-normalized fair comparison.
