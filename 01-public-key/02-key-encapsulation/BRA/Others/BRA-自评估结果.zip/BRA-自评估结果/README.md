# BRA x86 Self-Evaluation Results

This archive contains the x86 self-evaluation materials for the
BRA key encapsulation mechanism.

The official report is the English LaTeX-generated PDF in `自评估报告/`.
The corresponding LaTeX source is included next to the PDF.

The `自评估代码和数据/results/current/` directory contains filtered
machine-readable evidence:

- `kat.csv`, `resources.csv`, and `sizes.csv` contain only BRA rows.
- `performance.csv` contains BRA, FrodoKEM, and HQC rows to
  reproduce the controlled baseline performance reference.
- `raw_cycles.csv` contains the corresponding per-sample inner-loop statistics:
  mean cycles, median cycles, standard deviation, and intra-sample CV. Warm-up
  samples are excluded.

FrodoKEM and HQC do not use the NGCC submission API in their official
implementations. Their rows are contextual baseline data and must not be
interpreted as a strict API-normalized fair comparison.

Temporary runner binaries are intentionally excluded from this archive.
