# Dependency Statement

This self-evaluation uses the repository build system and the generated
`bin/` artifacts from `rbc-lib.py`.

## Build and Test Tools

- GCC: recorded in `self_eval/results/current/environment.json`.
- CMake: recorded in `self_eval/results/current/environment.json`.
- OpenSSL libcrypto: linked by the benchmark and self-evaluation harness.
- GNU `taskset`, `size`, and `/usr/bin/time`: used for CPU pinning and resource measurement.

## Cryptographic Support Code

- API_PKC auxiliary code: `drng.c/h`, `auxfunc.c/h`, KAT templates, and the KEM API wrappers are copied into the ICCS packaging tree.
- XKCP: Keccak/SHAKE sources are bundled under `lib/XKCP`; `lib/XKCP/README.md` records the upstream commit and borrowed Picnic files.
- Randomness for reproducible self-evaluation uses the NIST-style deterministic `randombytes_init` interface with a fixed 48-byte seed recorded in `environment.json`.
- FrodoKEM baseline performance uses the upstream KAT DRBG (`FrodoKEM/FrodoKEM/tests/rng.c`) with the same fixed 48-byte seed.
- HQC baseline performance uses the upstream SHAKE PRNG (`prng_init`) with the same fixed 48-byte seed.

## Implementation Versions

- `Reference_Implementation`: mapped to the generated `librbc-nist-ref.a` c64 build and ICCS Reference directories.
- `Optimized_Implementation`: mapped to the generated `librbc-nist.a` AVX2 build and ICCS Optimized directories.

## Baseline Algorithms

- FrodoKEM: `Frodo-640`, `Frodo-976`, and `Frodo-1344` from `baseline/FrodoKEM`.
- HQC: `HQC-1`, `HQC-3`, and `HQC-5` from `baseline/HQC`.
- Baseline algorithms are included only in `performance.csv` and the horizontal performance comparison tables. KAT, resource, and size evidence remain scoped to the NGCC candidate implementations.
